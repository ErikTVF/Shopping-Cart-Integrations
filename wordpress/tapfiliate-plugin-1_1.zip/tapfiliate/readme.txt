=== Tapfiliate ===
Contributors: Tapfiliate
Tags: javascript, Tapfiliate
Requires at least: 2.7
Tested up to: 3.9.1

Easily integrate the Tapfiliate tracking code

== Description ==

This plugin adds the Tapfiliate tracking code to all pages

== Installation ==

1. Upload `tapfiliate` directory to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Add your Tapfiliate account id to the settings (Admin > Settings > Tapfiliate)
